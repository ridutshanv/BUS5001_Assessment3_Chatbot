from flask import Flask, request, jsonify

app = Flask(__name__)

# ---------------------------------------------------------------------
#   DATASET – 9 Australian cities with attractions
# ---------------------------------------------------------------------
ATTRACTIONS = {
    "sydney": [
        {"name": "Sydney Opera House", "ticket": "AUD 43", "hours": "9 am–5 pm daily",
         "desc": "UNESCO-listed performing-arts centre on the harbour.", "lat": -33.8568, "lon": 151.2153},
        {"name": "Bondi Beach", "ticket": "Free", "hours": "24 hours",
         "desc": "World-famous surf beach and coastal-walk hotspot.", "lat": -33.8915, "lon": 151.2767},
        {"name": "Sydney Harbour Bridge", "ticket": "AUD 19 (climb extra)", "hours": "24 hours",
         "desc": "Iconic steel arch bridge linking the CBD to North Sydney.", "lat": -33.8523, "lon": 151.2108},
        {"name": "Taronga Zoo", "ticket": "AUD 51 (adult)", "hours": "9:30 am–5 pm",
         "desc": "Harbour-view zoo home to 4000 animals.", "lat": -33.8430, "lon": 151.2413},
        {"name": "Darling Harbour", "ticket": "Free", "hours": "24 hours",
         "desc": "Waterfront precinct with dining, shopping & museums.", "lat": -33.8728, "lon": 151.1990},
    ],
    "melbourne": [
        {"name": "Federation Square", "ticket": "Free", "hours": "24 hours",
         "desc": "Cultural precinct hosting galleries & events downtown.", "lat": -37.8179, "lon": 144.9691},
        {"name": "Royal Botanic Gardens", "ticket": "Free", "hours": "7:30 am–sunset",
         "desc": "Expansive landscaped gardens with native flora.", "lat": -37.8305, "lon": 144.9796},
        {"name": "Queen Victoria Market", "ticket": "Free", "hours": "Tue & Thu–Sun 6 am–3 pm",
         "desc": "Historic open-air market for food & souvenirs.", "lat": -37.8077, "lon": 144.9568},
        {"name": "Great Ocean Road", "ticket": "Free (self-drive)", "hours": "24 hours",
         "desc": "Famous coastal drive with the Twelve Apostles.", "lat": -38.6810, "lon": 143.3920},
        {"name": "Melbourne Museum", "ticket": "AUD 15 – 20", "hours": "10 am–5 pm",
         "desc": "Natural-history & culture museum in Carlton Gardens.", "lat": -37.8033, "lon": 144.9718},
    ],
    "brisbane": [
        {"name": "South Bank Parklands", "ticket": "Free", "hours": "24 hours",
         "desc": "Riverside park with a lagoon & restaurants.", "lat": -27.4811, "lon": 153.0234},
        {"name": "Story Bridge Adventure Climb", "ticket": "AUD 129 +", "hours": "Open daily",
         "desc": "Bridge-climb offering panoramic city views.", "lat": -27.4570, "lon": 153.0350},
        {"name": "Lone Pine Koala Sanctuary", "ticket": "AUD 49 (adult)", "hours": "9 am–5 pm",
         "desc": "World’s largest koala sanctuary.", "lat": -27.5337, "lon": 152.9755},
        {"name": "Mount Coot-tha Lookout", "ticket": "Free", "hours": "24 hours",
         "desc": "Scenic lookout over Brisbane skyline.", "lat": -27.4748, "lon": 152.9545},
        {"name": "Gallery of Modern Art", "ticket": "Free (main galleries)", "hours": "10 am–5 pm",
         "desc": "Australia’s largest modern-art museum.", "lat": -27.4710, "lon": 153.0183},
    ],
    "perth": [
        {"name": "Kings Park and Botanic Garden", "ticket": "Free", "hours": "24 hours",
         "desc": "One of the world’s largest inner-city parks.", "lat": -31.9617, "lon": 115.8428},
        {"name": "Cottesloe Beach", "ticket": "Free", "hours": "24 hours",
         "desc": "Golden-sand beach ideal for swimming & sunset.", "lat": -31.9942, "lon": 115.7510},
        {"name": "Perth Zoo", "ticket": "AUD 35 (adult)", "hours": "9 am–5 pm",
         "desc": "Zoo with 1250 animals from around the world.", "lat": -31.9830, "lon": 115.8711},
        {"name": "Elizabeth Quay", "ticket": "Free", "hours": "24 hours",
         "desc": "Harbourfront with restaurants & ferry terminal.", "lat": -31.9586, "lon": 115.8573},
        {"name": "Fremantle Markets", "ticket": "Free entry", "hours": "Fri–Sun 9 am–6 pm",
         "desc": "Historic market for food, crafts & live music.", "lat": -32.0556, "lon": 115.7480},
    ],
    "adelaide": [
        {"name": "Adelaide Oval", "ticket": "AUD 25 (tour)", "hours": "9 am–5 pm",
         "desc": "Iconic cricket ground & event venue.", "lat": -34.9156, "lon": 138.5969},
        {"name": "Art Gallery of South Australia", "ticket": "Free", "hours": "10 am–5 pm",
         "desc": "Gallery with 45,000 works of art.", "lat": -34.9213, "lon": 138.6048},
        {"name": "Glenelg Beach", "ticket": "Free", "hours": "24 hours",
         "desc": "Popular beach suburb reachable by tram.", "lat": -34.9792, "lon": 138.5146},
        {"name": "Adelaide Botanic Garden", "ticket": "Free", "hours": "7:15 am–5:30 pm",
         "desc": "Historic gardens near city centre.", "lat": -34.9180, "lon": 138.6066},
        {"name": "Barossa Valley", "ticket": "Free (entry)", "hours": "Cellar doors vary",
         "desc": "Renowned wine region north of Adelaide.", "lat": -34.5328, "lon": 138.9599},
    ],
    "canberra": [
        {"name": "Parliament House", "ticket": "Free", "hours": "9 am–5 pm",
         "desc": "Seat of Australia’s government with public tours.", "lat": -35.3080, "lon": 149.1245},
        {"name": "Australian War Memorial", "ticket": "Free", "hours": "10 am–5 pm",
         "desc": "Commemorates Australia’s military history.", "lat": -35.2813, "lon": 149.1470},
        {"name": "National Gallery of Australia", "ticket": "Free (main galleries)", "hours": "10 am–5 pm",
         "desc": "Houses 155,000+ works including Aboriginal art.", "lat": -35.2970, "lon": 149.1346},
        {"name": "Lake Burley Griffin", "ticket": "Free", "hours": "24 hours",
         "desc": "Artificial lake ideal for walking & cycling.", "lat": -35.2940, "lon": 149.1287},
        {"name": "Questacon Science Centre", "ticket": "AUD 23 (adult)", "hours": "9 am–5 pm",
         "desc": "Interactive science & technology museum.", "lat": -35.3055, "lon": 149.1291},
    ],
    "darwin": [
        {"name": "Mindil Beach Sunset Market", "ticket": "Free", "hours": "Thu & Sun 4 pm–9 pm",
         "desc": "Iconic sunset markets with food & art stalls.", "lat": -12.4385, "lon": 130.8307},
        {"name": "Crocosaurus Cove", "ticket": "AUD 38 (adult)", "hours": "9 am–5 pm",
         "desc": "See saltwater crocodiles in the city centre.", "lat": -12.4627, "lon": 130.8418},
        {"name": "Litchfield National Park", "ticket": "Free (entry)", "hours": "8 am–7 pm",
         "desc": "National park with waterfalls & rock pools.", "lat": -13.1628, "lon": 130.8226},
        {"name": "Museum and Art Gallery of NT", "ticket": "Free", "hours": "10 am–4 pm",
         "desc": "Exhibits on NT history, Cyclone Tracy & art.", "lat": -12.4409, "lon": 130.8303},
    ],
    "hobart": [
        {"name": "MONA (Museum of Old and New Art)", "ticket": "AUD 35 (adult)", "hours": "10 am–5 pm",
         "desc": "Provocative modern-art museum on the Derwent.", "lat": -42.8123, "lon": 147.2429},
        {"name": "Salamanca Market", "ticket": "Free", "hours": "Sat 8:30 am–3 pm",
         "desc": "Outdoor market with 300+ stalls near waterfront.", "lat": -42.8870, "lon": 147.3317},
        {"name": "Mount Wellington", "ticket": "Free", "hours": "24 hours",
         "desc": "Lookout with panoramic views of Hobart.", "lat": -42.8940, "lon": 147.2290},
        {"name": "Battery Point", "ticket": "Free", "hours": "24 hours",
         "desc": "Historic district with colonial architecture.", "lat": -42.8896, "lon": 147.3312},
        {"name": "Bruny Island", "ticket": "Ferry AUD 38 return (car)", "hours": "Ferry runs daily",
         "desc": "Island known for wildlife & scenic coastline.", "lat": -43.2610, "lon": 147.3220},
    ],
    "cairns": [
        {"name": "Great Barrier Reef", "ticket": "AUD 230 (day tour)", "hours": "Tours daily",
         "desc": "World’s largest coral-reef system.", "lat": -16.9186, "lon": 145.7781},
        {"name": "Kuranda Scenic Railway", "ticket": "AUD 50 – 80", "hours": "8:30 am–5 pm",
         "desc": "Train through rainforest & waterfalls.", "lat": -16.9230, "lon": 145.7769},
        {"name": "Cairns Esplanade Lagoon", "ticket": "Free", "hours": "6 am–9 pm",
         "desc": "Public lagoon & recreation area.", "lat": -16.9210, "lon": 145.7750},
        {"name": "Daintree Rainforest", "ticket": "AUD 30 (entry)", "hours": "7 am–6 pm",
         "desc": "Ancient tropical rainforest north of Cairns.", "lat": -16.1710, "lon": 145.4185},
        {"name": "Green Island", "ticket": "AUD 90 (ferry)", "hours": "8 am–5 pm",
         "desc": "Coral cay island with snorkelling & beaches.", "lat": -16.7613, "lon": 145.9708},
    ],
}

def maps_link(lat, lon):
    return f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"

def find_attr(city, text):
    text = text.lower()
    # Try to match attraction in that city
    for a in ATTRACTIONS.get(city, []):
        if a["name"].lower() in text:
            return a
    # If not found, search all cities
    for c in ATTRACTIONS:
        for a in ATTRACTIONS[c]:
            if a["name"].lower() in text:
                return a
    return None

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json(force=True)
    intent = data["queryResult"]["intent"]["displayName"]
    text = data["queryResult"]["queryText"].lower()

    # Extract city robustly
    raw_city = (data["queryResult"]["parameters"].get("city", "")
                or data["queryResult"]["parameters"].get("geo-city", "")
                or data["queryResult"]["parameters"].get("geo-location", ""))
    city = raw_city[0].lower() if isinstance(raw_city, list) and raw_city else str(raw_city).lower().strip()

    # Extract attraction robustly
    raw_attr = (data["queryResult"]["parameters"].get("attractions", "")
                or data["queryResult"]["parameters"].get("attraction", "")
                or data["queryResult"]["parameters"].get("geo-city", "")
                or data["queryResult"]["parameters"].get("geo-location", ""))
    attraction = raw_attr[0].lower() if isinstance(raw_attr, list) and raw_attr else str(raw_attr).lower().strip()

    # Recover last context values
    last_city, last_attr = city, None
    for ctx in data["queryResult"].get("outputContexts", []):
        if "awaiting-info" in ctx["name"]:
            p = ctx.get("parameters", {})
            last_city = p.get("city", last_city)
            last_attr = p.get("attraction", last_attr)

    print(f"Intent={intent}, City={last_city}, Attraction text='{attraction or text}'")

    reply = "Sorry, I didn't understand that."

    # ----- 1️⃣ List attractions -----
    if intent == "Find_Attractions":
        if city in ATTRACTIONS:
            names = [a["name"] for a in ATTRACTIONS[city]]
            reply = f"Top attractions in {city.title()}:\n• " + "\n• ".join(names)
            reply += "\n\nWhich one would you like details or directions for?"
            return jsonify({
                "fulfillmentText": reply,
                "outputContexts": [{
                    "name": f"{data['session']}/contexts/awaiting-info",
                    "lifespanCount": 5,
                    "parameters": {"city": city}
                }]
            })
        else:
            reply = "I currently have data for major Australian cities."

    # ----- 2️⃣ Choose attraction -----
    elif intent == "Choose_Attraction":
        a = find_attr(last_city, attraction or text)
        if not a:
            reply = "Please select one of the attractions I mentioned."
        else:
            reply = (f"{a['name']} ({last_city.title()})\n{a['desc']}\n\n"
                     f"📍 Directions: {maps_link(a['lat'], a['lon'])}\n"
                     f"🎟️ Ticket: {a['ticket']}\n"
                     f"🕐 Hours: {a['hours']}\nWould you like info on another attraction?")
            return jsonify({
                "fulfillmentText": reply,
                "outputContexts": [{
                    "name": f"{data['session']}/contexts/awaiting-info",
                    "lifespanCount": 5,
                    "parameters": {"city": last_city, "attraction": a['name']}
                }]
            })

    # ----- 3️⃣ Directions / Ticket / Hours / Description -----
    elif intent in ("Get_Directions", "Get_Ticket_Info", "Get_Hours", "Get_Description"):
        a = find_attr(last_city, attraction or text) or find_attr(last_city, last_attr or "")
        if not a:
            reply = "Please tell me which attraction you mean."
        else:
            if intent == "Get_Directions":
                reply = f"Directions to {a['name']} ({last_city.title()}): {maps_link(a['lat'], a['lon'])}"
            elif intent == "Get_Ticket_Info":
                reply = f"Ticket price for {a['name']}: {a['ticket']}"
            elif intent == "Get_Hours":
                reply = f"{a['name']} opening hours: {a['hours']}"
            elif intent == "Get_Description":
                reply = f"About {a['name']}: {a['desc']}"

    return jsonify({"fulfillmentText": reply})

if __name__ == "__main__":
    app.run(port=8080, debug=True)
