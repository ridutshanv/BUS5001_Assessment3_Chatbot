import streamlit as st
from openai import OpenAI
from pydantic import BaseModel, Field
from typing import Literal
import json

# Your OpenAI API Key (can be changed in the sidebar when running the app)
OPENAI_API_KEY = "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"

# Pydantic models for structured output
class Analysis(BaseModel):
    """Analysis of customer message"""
    issue_category: Literal["Billing", "Network", "Technical Support", "Account Access", "General Enquiry"] = Field(
        description="Category of the issue"
    )
    urgency_level: Literal["Low", "Medium", "High", "Critical"] = Field(
        description="Urgency level of the issue"
    )
    sentiment: Literal["Positive", "Neutral", "Negative"] = Field(
        description="Sentiment of the message"
    )
    followup_required: Literal["Y", "N"] = Field(
        description="Whether followup is required"
    )
    recommended_team: str = Field(
        description="Team that should handle this issue"
    )
    followup_reason: str = Field(
        description="Brief reason for followup"
    )

class CustomerMessageAnalysis(BaseModel):
    """Complete analysis of customer message"""
    message: str = Field(description="Original customer message")
    analysis: Analysis = Field(description="Analysis of the message")


# Define prompts
TELECOM_PROMPT = """You are an assistant for a telecommunications provider. 
Your task is to analyze customer messages and return a structured JSON with the following fields:

For each message, extract:
- issue_category: One of ["Billing", "Network", "Technical Support", "Account Access", "General Enquiry"]
- urgency_level: ["Low", "Medium", "High", "Critical"]
- sentiment: ["Positive", "Neutral", "Negative"]
- followup_required: "Y" or "N"
- recommended_team: e.g. "Billing Team", "Network Operations", "Technical Support", "Customer Care"
- followup_reason: brief human-readable reason

Return JSON ONLY in the following format:

{
 "message": "<original message>",
 "analysis": {
   "issue_category": "",
   "urgency_level": "",
   "sentiment": "",
   "followup_required": "",
   "recommended_team": "",
   "followup_reason": ""
 }
}"""

GENERAL_PROMPT = """A customer left a review. We follow up with anyone who appears unhappy. Extract all entities
mentioned. For each entity:
• classify sentiment as ["POSITIVE", "NEUTRAL", "NEGATIVE"]
• whether customer requires a follow-up: Y or N
• reason for requiring follow-up
Return JSON ONLY. No other text outside the JSON. JSON format:
{
entities: [{"entity_name": <entity name>,
"entity_type": <entity type>,
"entity_sentiment": <entity sentiment>,
"followup": <Y or N for follow-up>,
"followup_reason": <reason for follow-up>
}]
}
Review: <review text>."""


def analyze_message_with_openai(customer_message: str, prompt_type: str, api_key: str) -> dict:
    """
    Analyze customer message using OpenAI API
    - Telecom Prompt: Uses Pydantic for structured output
    - General Prompt: Uses raw JSON parsing
    """
    try:
        # Initialize client with the provided API key (clean initialization)
        openai_client = OpenAI(
            api_key=api_key,
            max_retries=2,
            timeout=30.0
        )
        
        # Select prompt based on user choice
        system_prompt = TELECOM_PROMPT if prompt_type == "Telecom Prompt" else GENERAL_PROMPT
        
        if prompt_type == "Telecom Prompt":
            # Use Pydantic structured output for Telecom Prompt
            completion = openai_client.beta.chat.completions.parse(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Message: {customer_message}"}
                ],
                response_format=CustomerMessageAnalysis,
            )
            
            # Extract the parsed response
            result = completion.choices[0].message.parsed
            return result.model_dump()
            
        else:
            # Use raw JSON for General Prompt (entity extraction)
            completion = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Review: {customer_message}"}
                ],
                temperature=0.3,
            )
            
            # Extract and parse JSON from response
            response_text = completion.choices[0].message.content
            
            # Try to parse as JSON
            try:
                result = json.loads(response_text)
                return result
            except json.JSONDecodeError:
                # If not valid JSON, try to extract JSON from the text
                import re
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    return result
                else:
                    st.error("Could not parse JSON from response")
                    return {"raw_response": response_text}
        
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        st.error(f"Error analyzing message: {str(e)}")
        st.error(f"Details: {error_details}")
        return None


# Streamlit App
def main():
    st.set_page_config(
        page_title="Customer Message Analyzer",
        page_icon="📞",
        layout="wide"
    )
    
    st.title("📞 Customer Message Analyzer")
    st.markdown("### Analyze customer messages with LLM")
    st.markdown("---")
    
    # Sidebar for configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # API Key input
        api_key_input = st.text_input(
            "OpenAI API Key", 
            value=OPENAI_API_KEY,
            type="password",
            help="Enter your OpenAI API key"
        )
        
        st.markdown("---")
        
        # Prompt selection
        st.subheader("Select Prompt Type")
        prompt_type = st.radio(
            "Choose prompt:",
            ["Telecom Prompt", "General Prompt"],
            help="Select which prompt to use for analysis"
        )
        
        st.markdown("---")
        st.markdown("### About")
        st.info(
            "**Telecom Prompt:** Uses OpenAI GPT-4 with Pydantic structured output for "
            "strict customer service analysis.\n\n"
            "**General Prompt:** Uses OpenAI GPT-4 with raw JSON for entity extraction "
            "from reviews."
        )
    
    # Main content area
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("📝 Enter Customer Message")
        
        # Text area for customer message
        customer_message = st.text_area(
            "Customer Message:",
            height=250,
            placeholder="Enter the customer message here...\n\nExample: I've been charged twice for my monthly plan. This is the second time this happens!"
        )
        
        # Analyze button
        analyze_button = st.button("🔍 Analyze Message", type="primary", use_container_width=True)
    
    with col2:
        st.subheader("📊 Analysis Results")
        
        if analyze_button:
            if not customer_message.strip():
                st.warning("⚠️ Please enter a customer message to analyze.")
            elif not api_key_input or api_key_input == "sk-proj-your-api-key-here" or len(api_key_input) < 20:
                st.error("❌ Please enter a valid OpenAI API key in the sidebar.")
            else:
                with st.spinner("Analyzing message..."):
                    result = analyze_message_with_openai(customer_message, prompt_type, api_key_input)
                    
                    if result:
                        # Display results in a nice format
                        st.success("✅ Analysis Complete!")
                        
                        # Check which prompt type was used and display accordingly
                        if prompt_type == "Telecom Prompt":
                            # Display Telecom Prompt results (Pydantic structure)
                            analysis = result['analysis']
                            
                            # Create metrics
                            metric_col1, metric_col2, metric_col3 = st.columns(3)
                            
                            with metric_col1:
                                # Color code sentiment
                                sentiment_color = {
                                    "Positive": "🟢",
                                    "Neutral": "🟡",
                                    "Negative": "🔴"
                                }
                                st.metric(
                                    "Sentiment", 
                                    f"{sentiment_color.get(analysis['sentiment'], '⚪')} {analysis['sentiment']}"
                                )
                            
                            with metric_col2:
                                # Color code urgency
                                urgency_color = {
                                    "Low": "🟢",
                                    "Medium": "🟡",
                                    "High": "🟠",
                                    "Critical": "🔴"
                                }
                                st.metric(
                                    "Urgency", 
                                    f"{urgency_color.get(analysis['urgency_level'], '⚪')} {analysis['urgency_level']}"
                                )
                            
                            with metric_col3:
                                followup_icon = "✅" if analysis['followup_required'] == "Y" else "❌"
                                st.metric(
                                    "Followup Required", 
                                    f"{followup_icon} {analysis['followup_required']}"
                                )
                            
                            st.markdown("---")
                            
                            # Detailed information
                            st.markdown("#### 📋 Detailed Analysis")
                            
                            info_col1, info_col2 = st.columns(2)
                            
                            with info_col1:
                                st.markdown(f"**Issue Category:**")
                                st.info(analysis['issue_category'])
                                
                                st.markdown(f"**Recommended Team:**")
                                st.info(analysis['recommended_team'])
                            
                            with info_col2:
                                st.markdown(f"**Followup Reason:**")
                                st.info(analysis['followup_reason'])
                        
                        else:
                            # Display General Prompt results (Entity extraction)
                            st.markdown("#### 📋 Entity Analysis")
                            
                            if 'entities' in result and result['entities']:
                                for idx, entity in enumerate(result['entities'], 1):
                                    with st.expander(f"🏷️ Entity {idx}: {entity.get('entity_name', 'Unknown')}", expanded=True):
                                        ent_col1, ent_col2 = st.columns(2)
                                        
                                        with ent_col1:
                                            st.write(f"**Type:** {entity.get('entity_type', 'N/A')}")
                                            sentiment = entity.get('entity_sentiment', 'N/A')
                                            sentiment_color = {
                                                "POSITIVE": "🟢",
                                                "NEUTRAL": "🟡",
                                                "NEGATIVE": "🔴"
                                            }
                                            st.write(f"**Sentiment:** {sentiment_color.get(sentiment, '⚪')} {sentiment}")
                                        
                                        with ent_col2:
                                            followup = entity.get('followup', 'N')
                                            followup_icon = "✅" if followup == "Y" else "❌"
                                            st.write(f"**Followup:** {followup_icon} {followup}")
                                            if followup == "Y":
                                                st.write(f"**Reason:** {entity.get('followup_reason', 'N/A')}")
                            else:
                                st.info("No entities extracted from the review.")
                        
                        st.markdown("---")
                        
                        # JSON Output
                        st.markdown("#### 🔍 Raw JSON Output")
                        st.json(result)
                        
                        # Download button
                        json_str = json.dumps(result, indent=2)
                        st.download_button(
                            label="📥 Download JSON",
                            data=json_str,
                            file_name="analysis_result.json",
                            mime="application/json"
                        )
        else:
            st.info("👈 Enter a customer message and click 'Analyze Message' to see results.")
    
    # Footer
    st.markdown("---")
    # st.markdown(
    #     "<div style='text-align: center; color: gray;'>"
    #     "Powered by OpenAI GPT-4 & Pydantic | Built with Streamlit"
    #     "</div>",
    #     unsafe_allow_html=True
    # )


if __name__ == "__main__":
    main()

