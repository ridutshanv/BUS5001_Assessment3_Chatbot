# Customer Message Analyzer 📞

A Streamlit application that uses OpenAI's GPT model with Pydantic for structured output to analyze customer messages and provide actionable insights.

## Features

- 🤖 **AI-Powered Analysis**: Uses OpenAI's GPT-4 for intelligent message analysis
- 📊 **Structured Output**: Pydantic models ensure consistent JSON output format
- 🎯 **Dual Prompt Support**: Choose between Telecom-specific or General prompts
- 📋 **Comprehensive Analysis**: Extracts issue category, urgency, sentiment, and more
- 🎨 **Beautiful UI**: Modern and intuitive interface with visual indicators
- 💾 **Export Results**: Download analysis results as JSON

## Installation

1. **Activate Virtual Environment** (if not already activated):
```bash
source venv/bin/activate
```

2. **Install Dependencies**:
```bash
pip install -r requirements.txt
```

## Configuration

### OpenAI API Key

You need an OpenAI API key to use this application. You can:

1. **Option 1**: Enter it directly in the sidebar when running the app
2. **Option 2**: Replace the placeholder in `app.py`:
   ```python
   OPENAI_API_KEY = "sk-proj-your-api-key-here"  # Replace with your actual API key
   ```

To get an API key:
- Visit [OpenAI Platform](https://platform.openai.com/)
- Sign in or create an account
- Go to API Keys section and create a new key

## Usage

### Running the Application

```bash
streamlit run app.py
```

The application will open in your default web browser at `http://localhost:8501`

### Using the Application

1. **Enter API Key**: In the sidebar, enter your OpenAI API key
2. **Select Prompt Type**: Choose between:
   - **Telecom Prompt**: Specialized for telecommunications customer service
   - **General Prompt**: General customer service analysis
3. **Enter Message**: 
   - Use one of the example messages, or
   - Write your own custom message
4. **Analyze**: Click the "Analyze Message" button
5. **View Results**: See the structured analysis with:
   - Sentiment (Positive/Neutral/Negative)
   - Urgency Level (Low/Medium/High/Critical)
   - Followup Required (Y/N)
   - Issue Category
   - Recommended Team
   - Followup Reason
6. **Export**: Download results as JSON if needed

## Analysis Fields

The application extracts the following information from each message:

| Field | Description | Possible Values |
|-------|-------------|-----------------|
| **issue_category** | Type of customer issue | Billing, Network, Technical Support, Account Access, General Enquiry |
| **urgency_level** | How urgent the issue is | Low, Medium, High, Critical |
| **sentiment** | Customer's emotional tone | Positive, Neutral, Negative |
| **followup_required** | Whether followup is needed | Y, N |
| **recommended_team** | Team to handle the issue | Billing Team, Network Operations, Technical Support, Customer Care |
| **followup_reason** | Why followup is needed | Brief explanation |

## Example Messages

### Billing Issue
```
I've been charged twice for my monthly plan. This is the second time this happens! I need this fixed immediately.
```

Expected Analysis:
- Category: Billing
- Urgency: High/Critical
- Sentiment: Negative
- Followup: Y

### Network Problem
```
My internet has been down for the past 3 hours. I work from home and this is unacceptable.
```

Expected Analysis:
- Category: Network
- Urgency: High
- Sentiment: Negative
- Followup: Y

### Positive Feedback
```
Just wanted to say thank you! The technician who came yesterday was very professional and fixed everything quickly.
```

Expected Analysis:
- Category: General Enquiry
- Urgency: Low
- Sentiment: Positive
- Followup: N

## Technical Details

### Models Used
- **Pydantic**: For data validation and structured output
- **OpenAI GPT-4o-mini**: For message analysis (cost-efficient)
- **Streamlit**: For the web interface

### Project Structure
```
.
├── app.py              # Main Streamlit application
├── requirements.txt    # Python dependencies
├── README.md          # This file
└── venv/              # Virtual environment
```

## Troubleshooting

### API Key Issues
- Ensure your API key is valid and has available credits
- Check that the key starts with `sk-`
- Make sure you have internet connection

### Installation Issues
- Ensure Python 3.8+ is installed
- Activate the virtual environment before installing dependencies
- Try upgrading pip: `pip install --upgrade pip`

### Application Issues
- Clear Streamlit cache: Click the menu (☰) → Clear cache
- Restart the application
- Check the terminal for error messages

## Notes

- The application uses `gpt-4o-mini` model for cost efficiency
- API calls are made in real-time, so ensure stable internet connection
- Each analysis costs a small amount based on OpenAI's pricing

## Support

For issues or questions, please refer to:
- [Streamlit Documentation](https://docs.streamlit.io/)
- [OpenAI API Documentation](https://platform.openai.com/docs/)
- [Pydantic Documentation](https://docs.pydantic.dev/)

